CREATE TABLE TempleDetails (
    Id Guid PRIMARY KEY 
    Name VARCHAR(50) NOT NULL,
    Location VARCHAR(50) NOT NULL,
    Capacity INT NOT NULL,
    IsActive BIT DEFAULT 1 NOT NULL, -- Checkbox for active/inactive status
    OpenTime TIME NOT NULL,
    CloseTime TIME NOT NULL,
    Description VARCHAR(100), -- Text area for description
    WebsiteUrl VARCHAR(30) NOT NULL,
    Email NVARCHAR(50) NOT NULL
);

CREATE TABLE QueueDetails (
    Id Guid PRIMARY KEY
    QueueName VARCHAR(50) NOT NULL,
    QueueType VARCHAR(50) NOT NULL, -- Dropdown for queue type   ex- Regular, Premium
    MaxCapacity INT NOT NULL,
    IsOpen BIT DEFAULT 1 NOT NULL, -- Checkbox for open/closed status
    BookingFee DECIMAL(10, 2) NOT NULL, -- Numeric input for booking fee
   TempleId Guid FOREIGN KEY REFERENCES TempleDetails(Id),
);

CREATE TABLE Users (
    Id				uniqueidentifier	PRIMARY KEY,
    FirstName		VARCHAR(20)		NOT NULL,
    LastName		VARCHAR(20)		NOT NULL,
    Email			VARCHAR(50)		NOT NULL,
	Password		VARCHAR(50)		NOT NULL,
    Phone			VARCHAR(20)		NOT NULL,
    DateOfBirth		DATE			NOT NULL,
	UserType		VARCHAR(10)		NOT NULL
);

ALTER TABLE Users 
ADD RefreshAccessToken VARCHAR(100),
	RefreshTokenExpiryDate DATETIME


CREATE TABLE Bookings (
    Id Guid PRIMARY KEY,
    PersonName VARCHAR(50) NOT NULL,
address VARCHAR(100) NOT NULL,
Country VARCHAR(10) NOT NULL -- dropdown,
state VARCHAR(20) NOT NULL -- dropdown,
 Email NVARCHAR(50) NOT NULL,
Pincode Int NOT NULL,
MobileNumber VARCHAR(20) NOT NULL,
No of Male Int NOT NULL,
No of female Int NOT NULL,
    TempleId Guid ,
    QueueId Guid ,
    Remarks VARCHAR(MAX), -- Text area for comments
BookingDate DATE NOT NULL,
    TimeSlot  VARCHAR (20) NOT NULL --dropdown,
    CONSTRAINT FK_TempleQueue FOREIGN KEY (TempleID, QueueID) REFERENCES QueueDetails(TempleID, QueueID),
);

INSERT INTO TempleDetails VALUES	
('3fa85f64-5717-4562-b3fc-2c963f66afb1','Golden Temple','Amritsar, Punjab',1000,1,'04:00','22:00','A prominent Sikh Gurdwara. The temple complex is open to people of all faiths and serves free meals to visitors.','https://www.goldentempleamritsar.org','info@goldentempleamritsar.org'),
('3fa85f64-5717-4562-b3fc-2c963f66afb3','Jagannath Temple','Puri, Odisha',1200,1,'06:00','22:00','A sacred Vaishnavite temple dedicated to Lord Jagannath, a form of Lord Krishna.','https://www.shreejagannatha.in','jagannath.or@nic.in'),
('3fa85f64-5717-4562-b3fc-2c963f66afc1','Kedarnath Temple','Kedarnath, Uttarakhand',500,1,'04:00','18:00','A Hindu temple dedicated to Lord Shiva. It is one of the twelve Jyotirlingas of Shiva','https://badrinath-kedarnath.gov.in','ceo.bktcddn@gmail.com'),
('3fa85f64-5717-4562-b3fc-2c963f66afc2','Shirdi Sai Baba Temple','Shirdi, Maharashtra',1000,1,'05:00','22:00','A shrine dedicated to Sai Baba of Shirdi, a spiritual leader and saint.','https://sai.org.in','saibaba@sai.org.in'),
('3fa85f64-5717-4562-b3fc-2c963f66afc3','Tirupati Balaji Temple','Tirupati, Andhra Pradesh',2500,1,'03:00','23:00','A major pilgrimage and cultural site. It is dedicated to Lord Venkateswara, an incarnation of Vishnu,','https://www.tirumala.org','helpdesk@tirumala.org'),
('3fa85f64-5717-4562-b3fc-2c963f66afc4','Vaishno Devi Temple','Katra, Jammu and Kashmir',1300,1,'06:00','20:00','A sacred cave dedicated to Goddess Vaishnavi, an incarnation of the Mother Goddess.','https://www.maavaishnodevi.org','online@maavaishnodevi.net'),
('3fa85f64-5717-4562-b3fc-2c963f66afc5','Somnath Temple','Prabhas Patan, Gujarat',2000,1,'07:00','21:00','An important pilgrimage site for Hindus.','https://somnath.org','somnathshahibaug@gmail.com');


INSERT INTO QueueDetails VALUES 
('3fa85f64-5717-4562-b3fc-2c963f66afa7','General Queue','Regular',500,1,100.00,'3FA85F64-5717-4562-B3FC-2C963F66AFB1'),
('3fa85f64-5717-4562-b3fc-2c963f66afa1','VIP Queue','Premium',100, 1, 300,'3FA85F64-5717-4562-B3FC-2C963F66AFB1')

  --{
  --  "queueName": "VIP Queue",
  --  "queueType": "Premium",
  --  "maxCapacity": 10,
  --  "isOpen": true,
  --  "bookingFee": 300,
  --  "templeId": "3fa85f64-5717-4562-b3fc-2c963f66afa6"
  --}


INSERT INTO Users VALUES	('FB1A5229-22DB-4DDD-B374-6C9C98A65E35','Rina', 'Gholap', 'admin76@gmail.com', 'Admin@1234','9056478976', '2000-11-01', 'Admin', null, null)

select * from TempleDetails
select * from QueueDetails
select * from Users
select * from Bookings