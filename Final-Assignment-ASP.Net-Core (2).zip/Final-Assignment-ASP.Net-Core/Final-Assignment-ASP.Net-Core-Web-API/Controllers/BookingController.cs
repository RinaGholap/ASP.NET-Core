﻿using Final_Assignment_ASP.Net_Core_Web_API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplicationCRUD.Interfaces;
using WebApplicationCRUD.Models;

namespace Final_Assignment_ASP.Net_Core_Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly IGenericRepository<Booking> _bookingRepository;
        private readonly EFCoreDbContext _dbContext;

        public BookingController(IGenericRepository<Booking> bookingRepository, EFCoreDbContext dbContext)
        {
            _bookingRepository = bookingRepository;
            _dbContext = dbContext;
        }

        [AllowAnonymous]
        [HttpGet("GetAllBookings")]
        public async Task<IEnumerable<Booking>> Index()
        {
            var bookings = await _dbContext.Bookings.Include(x => x.Temple).Include(x => x.Queue).Include(x => x.User).ToListAsync();
            
            return bookings;
        }

        [AllowAnonymous]
        [HttpGet("GetBooking/{id}")]
        public async Task<IActionResult> Details(Guid id)
        {
            var booking = await _dbContext.Bookings.Include(x => x.Temple).Include(x => x.Queue).Include(x => x.User).FirstOrDefaultAsync(x => x.Id == id);

            if (booking == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(booking);
            }
        }

        [AllowAnonymous]
        [HttpPost("AddBooking")]
        public async Task<IActionResult> Create(Booking booking)
        {
            if (ModelState.IsValid)
            {
                await _bookingRepository.InsertAsync(booking);
                await _bookingRepository.SaveAsync();

                return Ok();
            }
            else
            {
                return BadRequest();
            }            
        }

        [AllowAnonymous]
        [HttpPut("UpdateBooking/{id}")]
        public async Task<ActionResult> Edit(Guid id, Booking booking)
        {
            if (id != booking.Id)
            {
                return BadRequest();
            }
            else
            {
                await _bookingRepository.UpdateAsync(booking);
                await _bookingRepository.SaveAsync();

                return Ok();
            }
        }

        [AllowAnonymous]
        [HttpDelete("DeleteBooking/{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _bookingRepository.DeleteAsync(id);
            await _bookingRepository.SaveAsync();

            return Ok();
        }
    }
}
