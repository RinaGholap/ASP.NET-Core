﻿using Final_Assignment_ASP.Net_Core_Web_API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplicationCRUD.Interfaces;
using WebApplicationCRUD.Models;

namespace Final_Assignment_ASP.Net_Core_Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QueueDetailController : ControllerBase
    {
        private readonly IGenericRepository<QueueDetail> _queueDetailRepository;
        private readonly EFCoreDbContext _dbContext;

        public QueueDetailController(IGenericRepository<QueueDetail> queueDetailRepository, EFCoreDbContext dbContext)
        {
            _queueDetailRepository = queueDetailRepository;
            _dbContext = dbContext;
        }

        [AllowAnonymous]
        [HttpGet("GetAllQueueDetails")]
        public async Task<IEnumerable<QueueDetail>> Index()
        {
            var queueDetails = await _dbContext.QueueDetails.Include(x => x.Temple).ToListAsync();

            return queueDetails;
        }

        [AllowAnonymous]
        [HttpGet("GetQueueDetail/{id}")]
        public async Task<IActionResult> Details(Guid id)
        {
            var queueDetail = await _dbContext.QueueDetails.Include(x=> x.Temple).FirstOrDefaultAsync(y => y.Id == id);

            if (queueDetail == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(queueDetail);
            }
        }

        [AllowAnonymous]
        [HttpPost("AddQueueDetail")]
        public async Task<IActionResult> Create(QueueDetail queueDetail)
        {
            if (ModelState.IsValid)
            {
                await _queueDetailRepository.InsertAsync(queueDetail);
                await _queueDetailRepository.SaveAsync();

                return Ok();
            }
            else
            {
                return BadRequest();
            }
        }

        [AllowAnonymous]
        [HttpPut("UpdateQueueDetail/{id}")]
        public async Task<ActionResult> Edit(Guid id, QueueDetail queueDetail)
        {
            if (id != queueDetail.Id)
            {
                return BadRequest();
            }
            else
            {
                await _queueDetailRepository.UpdateAsync(queueDetail);
                await _queueDetailRepository.SaveAsync();

                return Ok();
            }
        }

        [AllowAnonymous]
        [HttpDelete("DeleteQueueDetail/{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _queueDetailRepository.DeleteAsync(id);
            await _queueDetailRepository.SaveAsync();

            return Ok();
        }
    }
}