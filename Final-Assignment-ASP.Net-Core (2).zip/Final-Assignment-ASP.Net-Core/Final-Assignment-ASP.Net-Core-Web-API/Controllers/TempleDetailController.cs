﻿using Final_Assignment_ASP.Net_Core_Web_API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplicationCRUD.Interfaces;

namespace Final_Assignment_ASP.Net_Core_Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TempleDetailController : ControllerBase
    {
        private readonly IGenericRepository<TempleDetail> _templeDetailRepository;

        public TempleDetailController(IGenericRepository<TempleDetail> templeDetailRepository)
        {
            _templeDetailRepository = templeDetailRepository;
        }

        [AllowAnonymous]
        [HttpGet("GetAllTempleDetails")]
        public async Task<IEnumerable<TempleDetail>> Index()
        {
            var templeDetails = await _templeDetailRepository.GetAllAsync();

            return templeDetails;
        }

        [AllowAnonymous]
        [HttpGet("GetTempleDetail/{id}")]
        public async Task<IActionResult> Details(Guid id)
        {
            var templeDetail = await _templeDetailRepository.GetByIdAsync(id);

            if (templeDetail == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(templeDetail);
            }
        }

        [AllowAnonymous]
        [HttpPost("AddTempleDetail")]
        public async Task<IActionResult> Create(TempleDetail templeDetail)
        {
            if (ModelState.IsValid)
            {
                await _templeDetailRepository.InsertAsync(templeDetail);
                await _templeDetailRepository.SaveAsync();

                return Ok();
            }
            else
            {
                return BadRequest();
            }
        }

        [AllowAnonymous]
        [HttpPut("UpdateTempleDetail/{id}")]
        public async Task<ActionResult> Edit (Guid id, TempleDetail templeDetail)
        {
            if (id != templeDetail.Id)
            {
                return BadRequest();
            }
            else
            {
                //var existingTempleDetail = await _templeDetailRepository.GetByIdAsync(id);
                //if (existingTempleDetail == null)
                //{
                //    return NotFound();
                //}

                await _templeDetailRepository.UpdateAsync(templeDetail);
                await _templeDetailRepository.SaveAsync();

                return Ok();
            }
        }

        [AllowAnonymous]
        [HttpDelete("DeleteTempleDetail/{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _templeDetailRepository.DeleteAsync(id);
            await _templeDetailRepository.SaveAsync();

            return Ok();
        }
    }
}