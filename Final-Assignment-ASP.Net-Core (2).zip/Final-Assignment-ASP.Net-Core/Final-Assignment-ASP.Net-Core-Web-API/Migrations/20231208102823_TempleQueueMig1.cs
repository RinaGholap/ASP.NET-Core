﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Final_Assignment_ASP.Net_Core_Web_API.Migrations
{
    public partial class TempleQueueMig1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
