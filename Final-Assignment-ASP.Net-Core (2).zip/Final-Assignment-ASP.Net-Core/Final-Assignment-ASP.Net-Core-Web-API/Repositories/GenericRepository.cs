﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using WebApplicationCRUD.Interfaces;
using WebApplicationCRUD.Models;

namespace WebApplicationCRUD.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private readonly EFCoreDbContext _dbContext;
        private readonly DbSet<T> _dbSet;

        public GenericRepository(EFCoreDbContext dbContext)
        {
            _dbContext = dbContext;
            //Whatever Entity name we specify while creating the instance of GenericRepository
            //That Entity name will be stored in the DbSet<T> variable
            _dbSet = _dbContext.Set<T>();
        }

        /// <summary>
        ///     This method will return all the Records from the table
        /// </summary>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task<IEnumerable<T>> GetAllAsync()
        {
            try
            {
                return await _dbSet.ToListAsync();
            }
            catch (Exception ex)
            {
                throw new Exception("Error occurred while getting all entities.", ex);
            }
        }

        /// <summary>
        ///     This method will return the specified record from the table
        ///     based on the Id which it received as an argument
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task<T?> GetByIdAsync(object Id)
        {
            try
            {
                return await _dbSet.FindAsync(Id);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error occurred while getting entity by Id: {Id}", ex);
            }
        }

        /// <summary>
        ///     This method will Insert one object into the table
        ///     It will receive the object as an argument which needs to be inserted into the database
        /// </summary>
        /// <param name="Entity"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task InsertAsync(T Entity)
        {
            try
            {
                await _dbSet.AddAsync(Entity);
            }
            catch (Exception ex)
            {
                throw new Exception("Error occurred while inserting entity.", ex);
            }
        }

        /// <summary>
        ///     This method is going to update the record in the table
        /// </summary>
        /// <param name="Entity"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task UpdateAsync(T Entity)
        {
            try
            {
                _dbSet.Update(Entity);
            }
            catch (Exception ex)
            {
                throw new Exception("Error occurred while updating entity.", ex);
            }
        }

        /// <summary>
        ///     This method is going to remove the record from the table
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task DeleteAsync(object Id)
        {
            try
            {
                var entity = await _dbSet.FindAsync(Id);
                if (entity != null)
                {
                    _dbSet.Remove(entity);
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error occurred while deleting entity by Id: {Id}", ex);
            }
        }

        /// <summary>
        ///     This method will make the changes permanent in the database.
        /// </summary>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task SaveAsync()
        {
            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new Exception("Error occurred while saving changes.", ex);
            }
        }
    }
}
