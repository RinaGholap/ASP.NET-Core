﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Final_Assignment_ASP.Net_Core_Web_API.Models
{
    public class QueueDetail
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string QueueName { get; set; }

        [Required]
        [MaxLength(20)]
        public string QueueType { get; set; }

        [Required]
        public int MaxCapacity { get; set; }

        [Required]
        public bool IsOpen { get; set; } = true;

        [Required]
        [Column(TypeName = "decimal(10, 2)")]
        public decimal BookingFee { get; set; }

        [Required]
        public Guid TempleId { get; set; }

        [ForeignKey(nameof(TempleId))]
        public TempleDetail? Temple { get; set; }

        [NotMapped]
        // Navigation property for the foreign key relationship
        public List<Booking>? Bookings { get; set; }
    }
}
