﻿using Final_Assignment_ASP.Net_Core_Web_API.Models;
using Microsoft.EntityFrameworkCore;

namespace WebApplicationCRUD.Models
{
    public class EFCoreDbContext : DbContext
    {
        //Constructor calling the Base DbContext Class Constructor
        public EFCoreDbContext(DbContextOptions<EFCoreDbContext> options) : base(options) { }

        //OnConfiguring() method is used to select and configure the data source
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) { }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TempleDetail>()
               .HasMany(t => t.Bookings)
               .WithOne(b => b.Temple)
               .OnDelete(DeleteBehavior.ClientSetNull);

            modelBuilder.Entity<QueueDetail>()
                .HasMany(q => q.Bookings)
                .WithOne(b => b.Queue)
                .OnDelete(DeleteBehavior.ClientSetNull);
        }

        //Adding Domain Classes as DbSet Properties
        public DbSet<User> Users { get; set; }
        public DbSet<TempleDetail> TempleDetails { get; set; }
        public DbSet<QueueDetail> QueueDetails { get; set; }
        public DbSet<Booking> Bookings { get; set; }
    }
}