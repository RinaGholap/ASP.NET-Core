﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Final_Assignment_ASP.Net_Core_Web_API.Models
{
    public class Booking
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string PersonName { get; set; }

        [Required]
        [MaxLength(200)]
        public string Address { get; set; }

        [Required]
        [MaxLength(20)]
        public string Country { get; set; }

        [Required]
        [MaxLength(30)]
        public string State { get; set; }

        [Required]
        [MaxLength(50)]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public int Pincode { get; set; }

        [Required]
        [MaxLength(20)]
        public string MobileNumber { get; set; }
        public int NumOfMale { get; set; }
        public int NumOfFemale { get; set; }
        public int NumOfChildren { get; set; }

        [MaxLength]
        public string Remarks { get; set; }

        [Required]
        public DateTime BookingDate { get; set; }

        [Required]
        [MaxLength(30)]
        public TimeSpan TimeSlot { get; set; }

        [Required]
        public bool IsConfirmed { get; set; }

        public Guid? TempleId { get; set; }

        public Guid? QueueId { get; set; }

        public Guid? UserId { get; set; }

        [ForeignKey(nameof(TempleId))]
        public virtual TempleDetail? Temple { get; set; }

        [ForeignKey(nameof(QueueId))]
        public virtual QueueDetail? Queue { get; set; }

        [ForeignKey(nameof(UserId))]
        public virtual User? User { get; set; }
    }
}