﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Final_Assignment_ASP.Net_Core_Web_API.Models
{
    public class TempleDetail
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        [Required]
        [MaxLength(100)]
        public string Location { get; set; }

        [Required]
        public int Capacity { get; set; }

        [Required]
        public bool IsActive { get; set; }

        [Required]
        public TimeSpan OpenTime { get; set; }

        [Required]
        public TimeSpan CloseTime { get; set; }

        [MaxLength(200)]
        public string Description { get; set; }

        [Required]
        [MaxLength(100)]
        public string WebsiteUrl { get; set; }

        [Required]
        [MaxLength(50)]
        public string Email { get; set; }

        [NotMapped]
        // Navigation property for the foreign key relationship
        public virtual List<QueueDetail>? Queues { get; set; }

        [NotMapped]
        // Navigation property for the foreign key relationship
        public virtual List<Booking>? Bookings { get; set; }
    }
}
