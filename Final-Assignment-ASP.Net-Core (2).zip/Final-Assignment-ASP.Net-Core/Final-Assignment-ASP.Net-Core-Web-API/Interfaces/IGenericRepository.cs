﻿namespace WebApplicationCRUD.Interfaces
{
    public interface IGenericRepository<T> where T : class
    {
        public Task<IEnumerable<T>> GetAllAsync();

        public Task<T?> GetByIdAsync(object id);

        public Task InsertAsync(T Entity);

        public Task UpdateAsync(T Entity);

        public Task DeleteAsync(object Id);

        public Task SaveAsync();
    }
}